from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from .models import *


class DateInput(forms.DateInput):
	input_type = 'date'


class ClientForm(ModelForm):
	class Meta:
		model = Client
		fields = '__all__'
		exclude = ['balance']
		widgets = {
			'id_card_date': DateInput(),
			'birth_date': DateInput()
		}


class ContractForm(ModelForm):
	class Meta:
		model = Contract
		fields = '__all__'
		exclude = []
		widgets = {
			'date_created': DateInput()
		}


class CreateUserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']


class PaymentForm(ModelForm):
	class Meta:
		model = Payment
		fields = '__all__'
		widgets = {
			'date_paid': DateInput()
		}


class GuarantorForm(ModelForm):
	class Meta:
		model = Fidejusor
		fields = '__all__'
		exclude = []
		widgets = {
			'id_card_date': DateInput(),
			'birth_date': DateInput()
		}

class PrognosisForm(ModelForm):
	PRODUCT = {
		('All', 'All'),
		('Classic', 'Classic'),
		('Special', 'Special'),
		('Imobil', 'Imobil')
	}
	product = forms.ChoiceField(choices=PRODUCT)
	class Meta:
		model = Prognosis
		fields = '__all__'
		widgets = {
			'start_date': DateInput(),
			'end_date': DateInput()
		}


class ArrearsForm(ModelForm):
	class Meta:
		model = Arrears
		fields = '__all__'
		widgets = {
			'date': DateInput()
		}
