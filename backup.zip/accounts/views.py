import dateutil.utils
from io import BytesIO
from docxtpl import DocxTemplate
import openpyxl
from django.shortcuts import render, redirect
from django.forms import modelform_factory
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.template.loader import get_template
from .process import render_to_pdf
from django.views.generic import View
from django.http import HttpResponse, StreamingHttpResponse
import os

# Create your views here.
from .models import *
from .forms import CreateUserForm, ClientForm, ContractForm, PaymentForm, GuarantorForm, PrognosisForm, ArrearsForm
from .filters import ClientFilter, ArrearsFilter, PrognosisFilter
from .decorators import unauthenticated_user, allowed_users, admin_only
from .functions import create_spread_sheet, verbose_loan, verbose_interest
from datetime import date, datetime
import json

class ExportXlsx(View):
    def get(self, request, *args, **kwargs):
        directory = os.getcwd()
        #path = directory + '/accounts/templates/pdf/statistics.xlsx'
        path = directory + '/CRM/accounts/templates/pdf/statistics.xlsx'
        wb_obj = openpyxl.load_workbook(path)

        contracts = Contract.objects.all()
        clients = Client.objects.all()
        all_clients_count = clients.count()
        female_clients_count = Client.objects.filter(gender="Female").count()
        physical_clients = []
        juridical_clients = []
        agri_ph = 0
        indu_ph = 0
        imob_ph = 0
        come_ph = 0
        serv_ph = 0
        cons_ph = 0
        alte_ph = 0
        agri_ju = 0
        indu_ju = 0
        imob_ju = 0
        come_ju = 0
        serv_ju = 0
        cons_ju = 0
        alte_ju = 0
        standard = []
        supravegheate = []
        substandard = []
        dubioase = []
        compromise = []
        standard_contracts = [0, 0]
        supravegheate_contracts = [0, 0]
        substandard_contracts = [0, 0]
        dubioase_contracts = [0, 0]
        compromise_contracts = [0, 0]
        busy = []
        tot = [0, 0, 0, 0, 0]
        for contract in contracts:
            if contract.client.person == "Physical":
                physical_clients.append(contract)
                if contract.sector == "Agricultură":
                    agri_ph += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Industria Alim. și Procesare":
                    indu_ph += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Imobil":
                    imob_ph += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Comerț":
                    come_ph += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Prestarea serviciilor":
                    serv_ph += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Consum":
                    cons_ph += int(contract.loan * contract.exchange_rate)
                else:
                    alte_ph += int(contract.loan * contract.exchange_rate)
            else:
                juridical_clients.append(contract)
                if contract.sector == "Agricultură":
                    agri_ju += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Industria Alim. și Procesare":
                    indu_ju += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Imobil":
                    imob_ju += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Comerț":
                    come_ju += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Prestarea serviciilor":
                    serv_ju += int(contract.loan * contract.exchange_rate)
                elif contract.sector == "Consum":
                    cons_ju += int(contract.loan * contract.exchange_rate)
                else:
                    alte_ju += int(contract.loan * contract.exchange_rate)
            payments = Payment.objects.filter(contract_id=contract.id)
            penalty_waives = PenaltyWaive.objects.filter(contract_id=contract.id)
            interest_waives = InterestWaive.objects.filter(contract_id=contract.id)
            table, profile, penalties = create_spread_sheet(
                str(contract.date_created).split(" ")[0],
                contract.months,
                contract.annual_payments,
                float(contract.loan),
                float(contract.interest_rate),
                contract.calc_method,
                str(date.today()),
                [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
                float(contract.month_sum),
                contract.grace_period,
                [int(waive.month) for waive in penalty_waives],
                [int(waive.month) for waive in interest_waives]
            )
            if profile[0][21] > 360 or contract.client_id in compromise:
                compromise.append(contract.client_id)
                compromise_contracts[0] += profile[0][10]
                compromise_contracts[1] += profile[0][13]
                busy.append(contract.client_id)
            elif profile[0][21] > 180 or contract.client_id in dubioase:
                dubioase_contracts[0] += profile[0][10]
                dubioase_contracts[1] += profile[0][13]
                dubioase.append(contract.client_id)
                busy.append(contract.client_id)
            elif profile[0][21] > 90 or contract.client_id in substandard:
                substandard_contracts[0] += profile[0][10]
                substandard_contracts[1] += profile[0][13]
                substandard.append(contract.client_id)
                busy.append(contract.client_id)
            elif profile[0][21] > 30 or contract.client_id in supravegheate:
                supravegheate_contracts[0] += profile[0][10]
                supravegheate_contracts[1] += profile[0][13]
                supravegheate.append(contract.client_id)
                busy.append(contract.client_id)
            elif profile[0][21] < 31 or contract.client_id in standard:
                standard_contracts[0] += profile[0][10]
                standard_contracts[1] += profile[0][13]
                standard.append(contract.client_id)


        sheet_10 = wb_obj.get_sheet_by_name('10_DG')
        c1 = sheet_10.cell(row=16, column=4)
        c1.value = str(all_clients_count)
        c2 = sheet_10.cell(row=17, column=4)
        c2.value = str(female_clients_count)
        sheet_11 = wb_obj.get_sheet_by_name('11_DU')
        c3 = sheet_11.cell(row=9, column=7)
        c3.value = '{:,}'.format(agri_ju).replace(',', '.').replace('.00', '')
        c4 = sheet_11.cell(row=10, column=7)
        c4.value = '{:,}'.format(indu_ju).replace(',', '.').replace('.00', '')
        c5 = sheet_11.cell(row=11, column=7)
        c5.value = '{:,}'.format(imob_ju).replace(',', '.').replace('.00', '')
        c6 = sheet_11.cell(row=12, column=7)
        c6.value = '{:,}'.format(come_ju).replace(',', '.').replace('.00', '')
        c7 = sheet_11.cell(row=13, column=7)
        c7.value = '{:,}'.format(serv_ju).replace(',', '.').replace('.00', '')
        c8 = sheet_11.cell(row=14, column=7)
        c8.value = '{:,}'.format(cons_ju).replace(',', '.').replace('.00', '')
        c9 = sheet_11.cell(row=15, column=7)
        c9.value = '{:,}'.format(alte_ju).replace(',', '.').replace('.00', '')
        c10 = sheet_11.cell(row=17, column=7)
        c10.value = '{:,}'.format(agri_ph).replace(',', '.').replace('.00', '')
        c11 = sheet_11.cell(row=18, column=7)
        c11.value = '{:,}'.format(indu_ph).replace(',', '.').replace('.00', '')
        c12 = sheet_11.cell(row=19, column=7)
        c12.value = '{:,}'.format(imob_ph).replace(',', '.').replace('.00', '')
        c13 = sheet_11.cell(row=20, column=7)
        c13.value = '{:,}'.format(come_ph).replace(',', '.').replace('.00', '')
        c14 = sheet_11.cell(row=21, column=7)
        c14.value = '{:,}'.format(serv_ph).replace(',', '.').replace('.00', '')
        c15 = sheet_11.cell(row=22, column=7)
        c15.value = '{:,}'.format(cons_ph).replace(',', '.').replace('.00', '')
        c16 = sheet_11.cell(row=23, column=7)
        c16.value = '{:,}'.format(alte_ph).replace(',', '.').replace('.00', '')

        sheet_8 = wb_obj.get_sheet_by_name('8_PN')
        b11 = sheet_8.cell(row=9, column=5)
        b11.value = str(int(standard_contracts[0]))
        b12 = sheet_8.cell(row=9, column=6)
        b12.value = str(int(standard_contracts[1]))
        b21 = sheet_8.cell(row=10, column=5)
        b21.value = str(int(supravegheate_contracts[0]))
        b22 = sheet_8.cell(row=10, column=6)
        b22.value = str(int(supravegheate_contracts[1]))
        b31 = sheet_8.cell(row=11, column=5)
        b31.value = str(int(substandard_contracts[0]))
        b32 = sheet_8.cell(row=11, column=6)
        b32.value = str(int(substandard_contracts[1]))
        b41 = sheet_8.cell(row=12, column=5)
        b41.value = str(int(dubioase_contracts[0]))
        b42 = sheet_8.cell(row=12, column=6)
        b42.value = str(int(dubioase_contracts[1]))
        b51 = sheet_8.cell(row=13, column=5)
        b51.value = str(int(compromise_contracts[0]))
        b52 = sheet_8.cell(row=13, column=6)
        b52.value = str(int(compromise_contracts[1]))



        buffer = BytesIO()
        wb_obj.save(buffer)  # save your memory stream
        buffer.seek(0)

        response = StreamingHttpResponse(
            streaming_content=buffer,  # use the stream's content
            content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )

        response['Content-Disposition'] = 'attachment;filename=Statistics.xlsx'
        response["Content-Encoding"] = 'UTF-8'

        return response


class ExportDocx(View):
    def get(self, request, pk, *args, **kwargs):
        # create an empty document object
        directory = os.getcwd()
        #document = DocxTemplate(directory + '/accounts/templates/pdf/template.docx')
        document = DocxTemplate(directory + '/CRM/accounts/templates/pdf/template.docx')
        contract = Contract.objects.get(id=pk)
        client = Client.objects.get(id=contract.client_id)
        payments = Payment.objects.filter(contract_id=pk)
        penalty_waives = PenaltyWaive.objects.filter(contract_id=pk)
        interest_waives = InterestWaive.objects.filter(contract_id=pk)
        guarantors = contract.fidejusor_set.all()
        table, profile, penalties = create_spread_sheet(
            str(contract.date_created).split(" ")[0],
            contract.months,
            contract.annual_payments,
            float(contract.loan),
            float(contract.interest_rate),
            contract.calc_method,
            str(date.today()),
            [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
            float(contract.month_sum),
            contract.grace_period,
            [int(waive.month) for waive in penalty_waives],
            [int(waive.month) for waive in interest_waives]
        )
        ptotal = 0
        itotal = 0
        stotal = 0
        tbl_contents = []
        for row in table:
            tbl_contents.append(
                {'nr': row[0],
                 'date': str(row[1]).replace('/', '.'),
                 'days': row[13],
                 'sum': "{:.2f}".format(row[2]),
                 'rate': "{:.2f}".format(row[3]),
                 'interest': "{:.2f}".format(row[12]),
                 'total': "{:.2f}".format(row[5])}
            )
            ptotal += row[3]
            itotal += row[12]
            stotal += row[5]

        char = 'b'
        guarantor_txt = ''
        for guarantor in guarantors:
            guarantor_txt += char + ")    Contract de fidejusiune nr. " + str(contract.id) + "-"
            guarantor_txt += str(guarantor.id) + " cu " + str(guarantor.last_name) + " "
            guarantor_txt += str(guarantor.first_name) + " (IDNP " + str(guarantor.idnp) + ")\n"
            char = chr(ord(char) + 1)
        if client.birth_date:
            context = {
                'id': pk,
                'contract_date': str(date.fromisoformat(str(contract.date_created)).strftime("%d.%m.%Y")),
                'first_name': client.first_name,
                'last_name': client.last_name,
                'location': client.location,
                'idnp': client.idnp,
                'birth_date': str(date.fromisoformat(str(client.birth_date)).strftime("%d.%m.%Y")),
                'loan_sum': "{:.2f}".format(contract.loan),
                'loan_sum_verbose': verbose_loan(round(float(contract.loan), 2)),
                'scope': contract.scope,
                'last_payment_date': str(table[len(table)-1][1]).replace('/', '.'),
                'interest_rate': "{:.2f}".format(contract.interest_rate),
                'interest_rate_verbose': verbose_interest(contract.interest_rate),
                'phone_num': client.phone_num,
                'bank_name': client.bank_name,
                'bank_code': client.bank_code,
                'bank_account': client.bank_account,
                'months': contract.months,
                'payments': str(int(contract.months / int(12 / contract.annual_payments))),
                'tbl_contents': tbl_contents,
                'guarantor_txt': guarantor_txt,
                'ptotal': "{:.2f}".format(ptotal),
                'itotal': "{:.2f}".format(itotal),
                'stotal': "{:.2f}".format(stotal),
            }
            document.render(context)
            buffer = BytesIO()
            document.save(buffer)
            buffer.seek(0)
            response = StreamingHttpResponse(
                streaming_content=buffer,  # use the stream's content
                content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
            response['Content-Disposition'] = 'attachment;filename=Contract_' + str(contract.id) + '.docx'
            response["Content-Encoding"] = 'UTF-8'
            return response
        else:
            messages.error(request, "Client lacks info")
            return redirect('/view_contract/' + str(pk) + '/')


class ExportDocxPaymentsMDL(View):
    def get(self, request, pk, *args, **kwargs):
        # create an empty document object
        directory = os.getcwd()
        #document = DocxTemplate(directory + '/accounts/templates/pdf/payments_mdl.docx')
        document = DocxTemplate(directory + '/CRM/accounts/templates/pdf/payments_mdl.docx')
        contract = Contract.objects.get(id=pk)
        client = Client.objects.get(id=contract.client_id)
        payments = Payment.objects.filter(contract_id=pk)
        penalty_waives = PenaltyWaive.objects.filter(contract_id=pk)
        interest_waives = InterestWaive.objects.filter(contract_id=pk)
        guarantors = contract.fidejusor_set.all()
        table, profile, penalties = create_spread_sheet(
            str(contract.date_created).split(" ")[0],
            contract.months,
            contract.annual_payments,
            float(contract.loan),
            float(contract.interest_rate),
            contract.calc_method,
            str(date.today()),
            [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
            float(contract.month_sum),
            contract.grace_period,
            [int(waive.month) for waive in penalty_waives],
            [int(waive.month) for waive in interest_waives]
        )

        tbl_contents = []
        k = 1
        total_p = 0
        for row in payments:
            tbl_contents.append(
                {
                'nr': k,
                'date': row.date_paid.strftime("%d/%m/%y"),
                'sum': "{:6,.2f}".format((float(round(row.sum / row.exchange_rate, 2))))
                }
            )
            total_p += float(round(row.sum / row.exchange_rate, 2))
            k += 1

        context = {
            'id': pk,
            'date': profile[0][0],
            'first_name': client.first_name,
            'last_name': client.last_name,
            'principal': "{:6,.2f}".format(contract.loan),
            'interest': "{:6,.2f}".format(profile[0][11]),
            'total': "{:6,.2f}".format(profile[0][11] + float(contract.loan)),
            'pay': "{:6,.2f}".format(total_p),
            'balance': "{:6,.2f}".format(total_p - (profile[0][11] + float(contract.loan)) - profile[0][9]),
            'penalty': "{:6,.2f}".format(profile[0][9]),
            'tbl_contents': tbl_contents
        }
        document.render(context)
        buffer = BytesIO()
        document.save(buffer)
        buffer.seek(0)
        response = StreamingHttpResponse(
            streaming_content=buffer,  # use the stream's content
            content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
        response['Content-Disposition'] = 'attachment;filename=Payments_' + str(contract.id) + '.docx'
        response["Content-Encoding"] = 'UTF-8'
        return response

class ExportDocx_Fide(View):
    def get(self, request, pk, *args, **kwargs):
        # create an empty document object
        directory = os.getcwd()
        #document = DocxTemplate(directory + '/accounts/templates/pdf/template2.docx')
        document = DocxTemplate(directory + '/CRM/accounts/templates/pdf/template2.docx')
        guarantor = Fidejusor.objects.get(id=pk)
        contract = guarantor.contract
        client = contract.client

        payments = Payment.objects.filter(contract_id=contract.id)
        penalty_waives = PenaltyWaive.objects.filter(contract_id=contract.id)
        interest_waives = InterestWaive.objects.filter(contract_id=contract.id)

        table, profile, penalties = create_spread_sheet(
            str(contract.date_created).split(" ")[0],
            contract.months,
            contract.annual_payments,
            float(contract.loan),
            float(contract.interest_rate),
            contract.calc_method,
            str(date.today()),
            [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
            float(contract.month_sum),
            contract.grace_period,
            [int(waive.month) for waive in penalty_waives],
            [int(waive.month) for waive in interest_waives]
        )

        context = {
            'id': str(contract.id) + '-' + str(guarantor.num),
            'contract_date': str(date.fromisoformat(str(contract.date_created)).strftime("%d.%m.%Y")),
            'first_name': guarantor.first_name,
            'last_name': guarantor.last_name,
            'location': guarantor.location,
            'id_card_nr': guarantor.id_card_nr,
            'id_card_office': guarantor.id_card_office,
            'id_card_date': str(date.fromisoformat(str(guarantor.id_card_date)).strftime("%d.%m.%Y")),
            'idnp': guarantor.idnp,
            'birth_date': str(date.fromisoformat(str(guarantor.birth_date)).strftime("%d.%m.%Y")),
            'c_id': str(contract.id),
            'c_first_name': client.first_name,
            'c_last_name': client.last_name,
            'c_location': client.location,
            'c_id_card_nr': client.id_card_nr,
            'c_id_card_office': client.id_card_office,
            'c_id_card_date': client.id_card_date,
            'c_idnp': client.idnp,
            'c_birth_date': client.birth_date,
            'loan_sum': "{:.2f}".format(contract.loan),
            'loan_sum_verbose': verbose_loan(round(float(contract.loan), 2)),
            'last_payment_date': str(table[len(table)-1][1]).replace('/', '.'),
            'phone_num': guarantor.phone_num,
        }
        document.render(context)


        # save document info
        buffer = BytesIO()
        document.save(buffer)  # save your memory stream
        buffer.seek(0)  # rewind the stream

        # put them to streaming content response
        # within docx content_type
        response = StreamingHttpResponse(
            streaming_content=buffer,  # use the stream's content
            content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )

        response['Content-Disposition'] = 'attachment;filename=ContractFidejusiune_' + str(contract.id) + '-' + str(guarantor.num) + '.docx'
        response["Content-Encoding"] = 'UTF-8'

        return response


class GeneratePDF(View):
    def get(self, request, pk, *args, **kwargs):
        #template = get_template('pdf/payments.html')
        directory = os.getcwd()
        template = get_template(directory + '/CRM/accounts/templates/pdf/payments.pdf')
        contract = Contract.objects.get(id=pk)
        client = Client.objects.get(id=contract.client_id)
        payments = Payment.objects.filter(contract_id=pk)
        count = 0

        guarantors = Fidejusor.objects.filter(contract=contract)

        all_payments = []
        for payment in payments:
            count += 1
            if contract.currency == "EUR":
                all_payments.append([
                    payment,
                    count,
                    True,
                    round(float(payment.exchange_rate), 2),
                    round(float(payment.sum / payment.exchange_rate), 2),
                ])
            else:
                all_payments.append([
                    payment,
                    count,
                    False
                ])

        total_mdl = 0
        total_eur = 0
        for payment in payments:
            total_mdl += payment.sum
            total_eur += payment.sum / payment.exchange_rate
        totals = (round(float(total_mdl), 2),
                  round(float(total_eur), 2))

        penalty_waives = PenaltyWaive.objects.filter(contract_id=pk)
        interest_waives = InterestWaive.objects.filter(contract_id=pk)
        table, profile, penalties = create_spread_sheet(
            str(contract.date_created).split(" ")[0],
            contract.months,
            contract.annual_payments,
            float(contract.loan),
            float(contract.interest_rate),
            contract.calc_method,
            str(date.today()),
            [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
            float(contract.month_sum),
            contract.grace_period,
            [int(waive.month) for waive in penalty_waives],
            [int(waive.month) for waive in interest_waives]
        )
        context = {'client': client,
                   'table': table,
                   'profile': profile,
                   'penalties': penalties,
                   'all_payments': all_payments,
                   'contract': contract,
                   'total_payments': totals,
                   'guarantors': guarantors
                   }
        html = template.render(context)
        print(html)
        pdf = render_to_pdf('pdf/payments.html', context)
        #pdf = render_to_pdf(directory + '/CRM/accounts/templates/pdf/payments.pdf', context)
        if pdf:
            response = HttpResponse(pdf, content_type='application/pdf')
            filename = "Payments_" + str(contract.id) + ".pdf"
            content = "inline; filename='%s'" %(filename)
            download = request.GET.get("download")
            if download:
                content = "attachment; filename='%s'" %(filename)
            response['Content-Disposition'] = content
            return response
        return HttpResponse("Not found")


@unauthenticated_user
def registerPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            messages.success(request, 'Account was created for ' + username)

            return redirect('login')

    context = {'form': form}
    return render(request, 'accounts/register.html', context)


@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'accounts/login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
@admin_only
def home(request):
    if request.method == 'POST':
        search_str = json.loads(request.body).get('searchText')
    clients = Client.objects.all()
    total_clients = clients.count()
    myFilter = ClientFilter(request.GET, queryset=clients)
    clients = myFilter.qs

    context = {'clients': clients,
               'total_clients': total_clients,
               'myFilter': myFilter}

    return render(request, 'accounts/my_dashboard.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def arrears(request, pk):
    contracts_list = Contract.objects.all()
    if pk == '0':
        proc_date = date.today()
    else:
        proc_date = date.fromisoformat(pk)
    form = ArrearsForm(initial={
        'date': proc_date
    })
    myFilter = ArrearsFilter(request.GET, queryset=contracts_list)
    contracts_list = myFilter.qs
    contracts = []
    profile = [0, 0, 0, 0, 0]
    filter = [1, 0, 0, 0, 0]
    count = contracts_list.count()
    for contract_data in contracts_list:
        payments = Payment.objects.filter(contract_id=contract_data.id)
        client = Client.objects.get(id=contract_data.client_id)
        if contract_data.date_created > proc_date:
            continue
        penalty_waives = PenaltyWaive.objects.filter(contract_id=contract_data.id)
        interest_waives = InterestWaive.objects.filter(contract_id=contract_data.id)
        contracts.append([
            contract_data.id,
            str(client.last_name) + " " + str(client.first_name),
            create_spread_sheet(
                str(contract_data.date_created).split(" ")[0],
                contract_data.months,
                contract_data.annual_payments,
                float(contract_data.loan),
                float(contract_data.interest_rate),
                contract_data.calc_method,
                str(proc_date),
                [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
                float(contract_data.month_sum),
                contract_data.grace_period,
                [int(waive.month) for waive in penalty_waives],
                [int(waive.month) for waive in interest_waives]
            )[1],
            contract_data.client_id
        ])
    contracts.sort(key=lambda x: x[2][0][21])
    for contract in contracts:
        profile[0] += contract[2][0][10]
        profile[1] += contract[2][0][12]
        if contract[2][0][21] > 30:
            profile[2] += contract[2][0][4]
        profile[4] += contract[2][0][5]
    if profile[1] > 0:
        profile[3] = round((profile[2] / profile[1]) * 100, 2)
    for i in range(len(profile)):
        profile[i] = round(profile[i], 2)

    if request.method == 'POST':
        form = ArrearsForm(request.POST)
        if form.is_valid():
            proc_date = form.data.get('date')
            return redirect('/arrears/' + proc_date + '/')

    context = {'contracts': contracts,
               'profile': profile,
               'filter': filter,
               'myFilter': myFilter,
               'count': count,
               'form': form}
    return render(request, 'accounts/arrears.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def client(request, pk_test):
    client = Client.objects.get(id=pk_test)
    contracts_list = client.contract_set.all()
    contracts_count = contracts_list.count()
    contracts = []
    for contract_data in contracts_list:
        payments = Payment.objects.filter(contract_id=contract_data.id)
        penalty_waives = PenaltyWaive.objects.filter(contract_id=contract_data.id)
        interest_waives = InterestWaive.objects.filter(contract_id=contract_data.id)
        contracts.append([
            contract_data.id,
            contract_data.date_created,
            contract_data.product,
            contract_data.loan,
            contract_data.status,
            create_spread_sheet(
                str(contract_data.date_created).split(" ")[0],
                contract_data.months,
                contract_data.annual_payments,
                float(contract_data.loan),
                float(contract_data.interest_rate),
                contract_data.calc_method,
                str(date.today()),
                [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
                float(contract_data.month_sum),
                contract_data.grace_period,
                [int(waive.month) for waive in penalty_waives],
                [int(waive.month) for waive in interest_waives]
            )[1]
            ])
    context = {'client': client, 'contracts': contracts, 'contracts_count': contracts_count}
    return render(request, 'accounts/client.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createContract(request, pk):
    client = Client.objects.get(id=pk)
    ContractForms = modelform_factory(Contract, form=ContractForm)
    form = ContractForms(initial={'client': client})
    client_id = client.pk
    created = False
    if request.method == 'POST':
        form = ContractForm(request.POST)
        if form.is_valid():
            form.save()
            contract = Contract.objects.get(id=form.data.get('id'))
            return redirect('/view_contract/' + str(contract.id) + '/')
    context = {'form': form, 'created': created}
    return render(request, 'accounts/contract_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateContract(request, pk):
    contract = Contract.objects.get(id=pk)
    form = ContractForm(instance=contract)
    created = True
    guarantors = contract.fidejusor_set.all()
    count = guarantors.count()
    if request.method == 'POST':
        form = ContractForm(request.POST, instance=contract)
        if form.is_valid():
            form.save()
            return redirect(f'/client/{contract.client_id}/')
    context = {'form': form,
               'created': created,
               'guarantors': guarantors,
               'count': count,
               'contract': contract}
    return render(request, 'accounts/contract_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def viewContract(request, pk):
    contract = Contract.objects.get(id=pk)
    client = Client.objects.get(id=contract.client_id)
    payments = Payment.objects.filter(contract_id=pk)
    count = 0

    guarantors = Fidejusor.objects.filter(contract=contract)

    all_payments = []
    for payment in payments:
        count += 1
        if contract.currency == "EUR":
            all_payments.append([
                payment,
                count,
                True,
                round(float(payment.exchange_rate), 2),
                round(float(payment.sum / payment.exchange_rate), 2),
            ])
        else:
            all_payments.append([
                payment,
                count,
                False
            ])

    total_mdl = 0
    total_eur = 0
    for payment in payments:
        total_mdl += payment.sum
        total_eur += payment.sum / payment.exchange_rate
    totals = (round(float(total_mdl), 2),
              round(float(total_eur), 2))


    penalty_waives = PenaltyWaive.objects.filter(contract_id=pk)
    interest_waives = InterestWaive.objects.filter(contract_id=pk)
    table, profile, penalties = create_spread_sheet(
        str(contract.date_created).split(" ")[0],
        contract.months,
        contract.annual_payments,
        float(contract.loan),
        float(contract.interest_rate),
        contract.calc_method,
        str(date.today()),
        [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
        float(contract.month_sum),
        contract.grace_period,
        [int(waive.month) for waive in penalty_waives],
        [int(waive.month) for waive in interest_waives]
    )
    if request.method == 'POST':

        form = ContractForm(request.POST, instance=contract)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'client': client,
               'table': table,
               'profile': profile,
               'penalties': penalties,
               'all_payments': all_payments,
               'contract': contract,
               'total_payments': totals,
               'guarantors': guarantors
               }
    return render(request, 'accounts/contract_table.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteContract(request, pk):
    contract = Contract.objects.get(id=pk)
    client = contract.client
    client_id = client.pk
    if request.method == "POST":
        contract.delete()
        return redirect(f'/client/{client.id}/')
    context = {'item': contract}
    return render(request, 'accounts/delete_contract.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createClient(request):
    ClientForms = modelform_factory(Client, form=ClientForm, fields='__all__')
    form = ClientForms()
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            client = Client.objects.get(idnp=form.data.get('idnp'))
            return redirect('/client/' + str(client.id) + '/')
    context = {'form': form}
    return render(request, 'accounts/new_client.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateClient(request, pk):
    client = Client.objects.get(id=pk)
    form = ClientForm(instance=client)
    if request.method == 'POST':

        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            return redirect(f'/client/{client.id}/')

    context = {'form': form}
    return render(request, 'accounts/new_client.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteClient(request, pk):
    client = Client.objects.get(id=pk)
    if request.method == "POST":
        client.delete()
        return redirect('/')

    context = {'item': client}
    return render(request, 'accounts/delete_client.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createPayment(request, pk):
    contract = Contract.objects.get(id=pk)
    PaymentForms = modelform_factory(Payment, form=PaymentForm)
    form = PaymentForms(initial={'contract': contract})
    contract_id = contract.pk
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        new_form = Payment()
        if form.is_valid():
            form.save()
            return redirect('/view_contract/' + str(contract_id) + '/')
    context = {'form': form}
    return render(request, 'accounts/payment_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updatePayment(request, pk):
    payment = Payment.objects.get(id=pk)
    form = PaymentForm(instance=payment)
    if request.method == 'POST':
        form = PaymentForm(request.POST, instance=payment)
        if form.is_valid():
            form.save()
            return redirect(f'/view_contract/{payment.contract_id}/')
    context = {'form': form}
    return render(request, 'accounts/payment_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deletePayment(request, pk):
    payment = Payment.objects.get(id=pk)
    if request.method == "POST":
        payment.delete()
        return redirect(f'/view_contract/{payment.contract_id}/')

    context = {'item': payment}
    return render(request, 'accounts/delete_payment.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createPenaltyWaive(request, pk, pj):
    waive = PenaltyWaive(contract_id=pk, month=pj)
    waive.save()
    return redirect('/view_contract/' + str(waive.contract_id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createInterestWaive(request, pk, pj):
    waive = InterestWaive(contract_id=pk, month=pj)
    waive.save()
    return redirect('/view_contract/' + str(waive.contract_id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deletePenaltyWaive(request, pk, pj):
    waive = PenaltyWaive.objects.filter(contract_id=pk, month=pj)
    id = pk
    waive.delete()
    return redirect('/view_contract/' + str(id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteInterestWaive(request, pk, pj):
    waive = InterestWaive.objects.filter(contract_id=pk, month=pj)
    id = pk
    waive.delete()
    return redirect('/view_contract/' + str(id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def waiveAllInterest(request, pk):
    contract = Contract.objects.get(id=pk)
    for i in range(contract.months):
        waive = InterestWaive(contract_id=pk, month=i+1)
        waive.save()
    return redirect('/view_contract/' + str(waive.contract_id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def waiveAllPenalty(request, pk):
    contract = Contract.objects.get(id=pk)
    for i in range(contract.months):
        waive = PenaltyWaive(contract_id=pk, month=i+1)
        waive.save()
    return redirect('/view_contract/' + str(waive.contract_id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteAllPenalty(request, pk):
    contract = Contract.objects.get(id=pk)
    for i in range(contract.months):
        waive = PenaltyWaive.objects.filter(contract_id=pk, month=i+1)
        id = pk
        waive.delete()
    return redirect('/view_contract/' + str(id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteAllInterest(request, pk):
    contract = Contract.objects.get(id=pk)
    for i in range(contract.months):
        waive = InterestWaive.objects.filter(contract_id=pk, month=i+1)
        id = pk
        waive.delete()
    return redirect('/view_contract/' + str(id) + '/')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createGuarantor(request, pk):
    contract = Contract.objects.get(id=pk)
    GuarantorForms = modelform_factory(Fidejusor, form=GuarantorForm)
    form = GuarantorForms(initial={'contract': contract})
    contract_id = contract.pk
    if request.method == 'POST':
        form = GuarantorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/update_contract/' + str(contract_id) + '/')
    context = {'form': form}
    return render(request, 'accounts/guarantor_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteGuarantor(request, pk):
    guarantor = Fidejusor.objects.get(id=pk)
    if request.method == "POST":
        guarantor.delete()
        return redirect(f'/update_contract/{guarantor.contract.id}/')

    context = {'item': guarantor}
    return render(request, 'accounts/delete_guarantor.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateGuarantor(request, pk):
    guarantor = Fidejusor.objects.get(id=pk)
    form = GuarantorForm(instance=guarantor)
    if request.method == 'POST':
        form = GuarantorForm(request.POST, instance=guarantor)
        if form.is_valid():
            form.save()
            return redirect(f'/update_contract/{guarantor.contract.id}/')
    context = {'form': form}
    return render(request, 'accounts/guarantor_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def prognosis(request, pk, pj, pl):
    if pl == 'All':
        contracts_list = Contract.objects.filter(status='Active')
    else:
        contracts_list = Contract.objects.filter(status='Active', product=pl)
    start_date = datetime.fromisoformat(pk).date()
    end_date = datetime.fromisoformat(pj).date()
    form = PrognosisForm(initial={'start_date': start_date,
                                  'end_date': end_date,
                                  'product': pl
                                  })
    full = []
    total = [0, 0, 0, 0]
    for contract_data in contracts_list:
        payments = Payment.objects.filter(contract_id=contract_data.id)
        client = Client.objects.get(id=contract_data.client_id)
        penalty_waives = PenaltyWaive.objects.filter(contract_id=contract_data.id)
        interest_waives = InterestWaive.objects.filter(contract_id=contract_data.id)
        table, profile, penalties = create_spread_sheet(
            str(contract_data.date_created).split(" ")[0],
            contract_data.months,
            contract_data.annual_payments,
            float(contract_data.loan),
            float(contract_data.interest_rate),
            contract_data.calc_method,
            str(date.today()),
            [(float(round(payment.sum / payment.exchange_rate, 2)), payment.date_paid) for payment in payments],
            float(contract_data.month_sum),
            contract_data.grace_period,
            [int(waive.month) for waive in penalty_waives],
            [int(waive.month) for waive in interest_waives]
        )
        state = False
        data = [0, 0, 0]
        for tab in table:
            if tab[14] > start_date and tab[14] < end_date:
                state = True
                data[0] += tab[3]
                total[0] += tab[3]
                data[1] += tab[4]
                total[1] += tab[4]
                data[2] += tab[5]
                total[2] += tab[5]
        for i in range(len(data)):
            data[i] = round(data[i], 2)
        if state:
            full.append([
                str(contract_data.id),
                str(client.last_name) + ' ' + str(client.first_name),
                data
            ])
            total[3] += 1
    for i in range(len(total)):
        total[i] = round(total[i], 2)
    if request.method == 'POST':
        form = PrognosisForm(request.POST)
        if form.is_valid():
            start = form.data.get('start_date')
            end = form.data.get('end_date')
            product = form.data.get('product')
            return redirect('/prognosis/' + start + '/' + end + '/' + product + '/')
    context = {
        'data': full,
        'total': total,
        'form': form
    }
    return render(request, 'accounts/prognosis.html', context)

