import django_filters

from .models import *

PRODUCT = {
		('Classic', 'Classic'),
		('Imobil', 'Imobil'),
		('Special', 'Special'),
		('Consum', 'Consum')
	}

STATUS = (
		('Active', 'Active'),
		('Closed', 'Closed'),
		('Colectare', 'Colectare'),
		('Judecata', 'Judecata'),
		('Bad Client', 'Bad Client')
	)
class ClientFilter(django_filters.FilterSet):
	class Meta:
		model = Client
		fields = {
			'first_name',
			'last_name'
		}

class ArrearsFilter(django_filters.FilterSet):
	product = django_filters.ChoiceFilter(choices=PRODUCT, empty_label=('All'))
	status = django_filters.ChoiceFilter(choices=STATUS, empty_label=('All'))
	class Meta:
		model = Contract
		fields = {'id'}


class PrognosisFilter(django_filters.FilterSet):
	product = django_filters.ChoiceFilter(choices=PRODUCT, empty_label=('All'))
